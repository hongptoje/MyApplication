package com.example.hong.myapplication;

/**
 * Created by hong on 2018-03-22.
 */

public class Duration {
    public String text;
    public int value;

    public Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
