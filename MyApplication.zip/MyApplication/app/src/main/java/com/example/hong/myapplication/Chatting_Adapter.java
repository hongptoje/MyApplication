package com.example.hong.myapplication;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by hong on 2018-02-04.
 */

public class Chatting_Adapter extends RecyclerView.Adapter<Chatting_Adapter.ChattingViewHolder> {

    private ArrayList<chatting_item> chatting_list = new ArrayList<>();
    private Context context;

    public Chatting_Adapter(Context context, ArrayList<chatting_item> chatting_list) {
        this.context = context;
        this.chatting_list = chatting_list;
    }

    @Override
    public ChattingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chatting_item, parent, false);
        return new ChattingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ChattingViewHolder holder, int position) {
        chatting_item chatting_item = chatting_list.get(position);
        holder.chatting_message.setText(chatting_item.getMessage());
    }

    @Override
    public int getItemCount() {
        return chatting_list.size();
    }

    public class ChattingViewHolder extends RecyclerView.ViewHolder {
        public TextView chatting_message;


        public ChattingViewHolder(View itemView) {
            super(itemView);
            chatting_message = (TextView) itemView.findViewById(R.id.chatting_message);
        }
    }
}
