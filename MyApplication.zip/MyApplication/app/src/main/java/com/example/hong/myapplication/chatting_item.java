package com.example.hong.myapplication;

/**
 * Created by hong on 2018-02-04.
 */

public class chatting_item {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
