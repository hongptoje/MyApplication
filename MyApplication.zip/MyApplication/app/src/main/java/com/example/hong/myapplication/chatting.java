package com.example.hong.myapplication;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;

public class chatting extends AppCompatActivity {
    EditText send_message;
    ImageView send_message_button, back_button;
    TextView chatting_info, chatting_body;
    String name;
    Handler handler;
    ClientThread clientThread;
    ReceiveThread receiveThread;
    SendThread sendThread;
    Socket socket;
    String ip = "52.78.13.66";
    int port = 5001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatting);
        send_message = (EditText)findViewById(R.id.send_message);
        send_message_button = (ImageView)findViewById(R.id.send_message_button);
        back_button = (ImageView)findViewById(R.id.back_button);
        chatting_info = (TextView)findViewById(R.id.chatting_info);
        chatting_body = (TextView)findViewById(R.id.chatting_body);
        Intent intent = getIntent();
        name = intent.getStringExtra("friend_info");
        chatting_info.setText(name);
        clientThread = new ClientThread(ip, port);
        clientThread.start();

        //메시지 전송 버튼
        send_message_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendThread = new SendThread(socket);
                sendThread.start();
                send_message.setText("");
            }
        });

        //채팅창에 표시
        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 1111){
                    chatting_body.append(msg.obj.toString()+"\n");
                }
                super.handleMessage(msg);
            }
        };
    }

    //소켓  내부 클래스
    class ClientThread extends Thread{
        String ip;
        int port;

        public ClientThread(String ip, int port) {
            this.ip = ip;
            this.port = port;
        }

        @Override
        public void run() {
            super.run();
            try {
                socket = new Socket(ip, port);
                receiveThread = new ReceiveThread(socket);
                receiveThread.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //받는 부분 내부 클래스
    class ReceiveThread extends Thread{
        Socket socket;
        DataInputStream dataInputStream;
        String chatMessage;

        public ReceiveThread(Socket socket) {
            this.socket = socket;
            try {
                dataInputStream = new DataInputStream(socket.getInputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            super.run();
            try {
            while(dataInputStream != null){
                    chatMessage = dataInputStream.readUTF();
                    Log.i("readMessage",""+chatMessage);
                    Message msg = handler.obtainMessage();
                    msg.what = 1111;
                    msg.obj = chatMessage;
                    handler.sendMessage(msg);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //보내는 부분 내무 클래스
    class SendThread extends Thread{
        Socket socket;
        DataOutputStream dataOutputStream;
        String send = send_message.getText().toString();

        public SendThread(Socket socket) {
            this.socket = socket;
            try {
                dataOutputStream = new DataOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            super.run();
            try {
                dataOutputStream.writeUTF(send);
                Log.i("sendMessage", ""+ dataOutputStream);
                Log.i("sendMessage", ""+send);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
