package com.example.hong.myapplication;

/**
 * Created by hong on 2018-03-25.
 */

public class TransitDuration {
    public String text;
    public int value;

    public TransitDuration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
