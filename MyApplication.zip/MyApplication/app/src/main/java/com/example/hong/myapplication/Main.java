package com.example.hong.myapplication;

import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Main extends AppCompatActivity {
ImageButton friend_button, talk_button, setting_button;
ViewPager pager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        pager = (ViewPager)findViewById(R.id.pager);
        friend_button = (ImageButton)findViewById(R.id.friend_button);
        talk_button = (ImageButton)findViewById(R.id.talk_button);
        setting_button = (ImageButton)findViewById(R.id.setting_button);


        pager.setAdapter(new pagerAdapter(getSupportFragmentManager()));
        pager.setCurrentItem(0);
        View.OnClickListener movePageListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int tag = (int)v.getTag();
                pager.setCurrentItem(tag);
            }
        };
        friend_button.setOnClickListener(movePageListener);
        friend_button.setTag(0);
        talk_button.setOnClickListener(movePageListener);
        talk_button.setTag(1);
        setting_button.setOnClickListener(movePageListener);
        setting_button.setTag(2);
    }

    private class pagerAdapter extends FragmentStatePagerAdapter
    {
        public pagerAdapter(FragmentManager fm )
        {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            switch(position)
            {
                case 0:
                    return new friend();
                case 1:
                    return new talk();
                case 2:
                    return new setting();
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            // total page count
            return 3;
        }
    }


}
